package com.example.backend.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.SolicitudCompra;

public interface SolicitudCompraRepository extends JpaRepository<SolicitudCompra,Integer>{

}
