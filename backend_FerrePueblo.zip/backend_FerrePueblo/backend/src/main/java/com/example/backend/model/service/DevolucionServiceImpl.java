package com.example.backend.model.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.model.entity.DetalleDevolucion;
import com.example.backend.model.entity.Devolucion;
import com.example.backend.model.entity.Producto;
import com.example.backend.model.entity.Usuario;
import com.example.backend.model.repository.DevolucionRepository;
import com.example.backend.model.repository.ProductoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DevolucionServiceImpl implements DevolucionService{
    private final DevolucionRepository devolucionRepository;
    private final ProductoRepository productoRepository;  

    @Override
    @Transactional
    public Devolucion crear(Devolucion devolucion) {
    System.out.println("🔍 Service - Devolución recibida: " + devolucion);
    System.out.println("🔍 Service - Usuario: " + devolucion.getUsuario());
    
    // 1. AUMENTAR STOCK de productos devueltos
    if (devolucion.getDetalleDevolucion() != null) {
        for (DetalleDevolucion detalle : devolucion.getDetalleDevolucion()) {
            detalle.setDevolucion(devolucion);
            
            Producto productoDevuelto = productoRepository.findById(detalle.getProducto().getIdProducto())
                .orElseThrow(() -> new RuntimeException("Producto devuelto no encontrado"));
            productoDevuelto.setStock(productoDevuelto.getStock() + detalle.getCantidad());
            productoRepository.save(productoDevuelto);
            System.out.println("✅ Stock aumentado para producto devuelto ID: " + productoDevuelto.getIdProducto());
        }
    }
    
    // 2. DESCONTAR STOCK del nuevo producto (si existe)
    if (devolucion.getNuevoProducto() != null) {
        Integer idProductoNuevo = (Integer) devolucion.getNuevoProducto().get("idProducto");
        Integer cantidad = (Integer) devolucion.getNuevoProducto().get("cantidad");
        
        Producto productoNuevo = productoRepository.findById(idProductoNuevo)
            .orElseThrow(() -> new RuntimeException("Producto nuevo no encontrado"));
        productoNuevo.setStock(productoNuevo.getStock() - cantidad);
        productoRepository.save(productoNuevo);
        System.out.println("✅ Stock descontado para producto nuevo ID: " + productoNuevo.getIdProducto());
    }
    
    // ✅ Verificar que el usuario esté setteado (pero sin lanzar excepción si es null)
    if (devolucion.getUsuario() == null) {
        System.out.println("⚠️ Usuario es null, pero intentaremos guardar de todos modos");
        // En lugar de lanzar excepción, asignar un usuario por defecto (ID 1)
        devolucion.setUsuario(new Usuario(1));
        System.out.println("✅ Usuario por defecto asignado: ID 1");
    }
    
    System.out.println("🔍 Service - Usuario final: " + devolucion.getUsuario());
    System.out.println("🔍 Service - Venta final: " + devolucion.getVenta());
    
    return devolucionRepository.save(devolucion);
}
}
