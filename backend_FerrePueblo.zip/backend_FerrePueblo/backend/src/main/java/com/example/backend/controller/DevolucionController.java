package com.example.backend.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.backend.model.entity.Devolucion;
import com.example.backend.model.entity.Usuario;
import com.example.backend.model.entity.Venta;
import com.example.backend.model.service.DevolucionService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/devoluciones")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class DevolucionController {
    private final DevolucionService devolucionService;

    @PostMapping
    public ResponseEntity<Devolucion> crear(@RequestBody Devolucion devolucion) {
     System.out.println("🔍 Devolución recibida: " + devolucion);
    System.out.println("🔍 idUsuario recibido: " + devolucion.getIdUsuario());
    
    // ✅ Construir objetos con solo el ID
    if (devolucion.getUsuario() != null && devolucion.getUsuario().getIdUsuario() != null) {
        devolucion.setUsuario(new Usuario(devolucion.getUsuario().getIdUsuario()));
    } else if (devolucion.getIdUsuario() != null) {
        // ✅ Si el frontend envió idUsuario directamente
        devolucion.setUsuario(new Usuario(devolucion.getIdUsuario()));
        System.out.println("✅ Usuario seteado desde idUsuario: " + devolucion.getIdUsuario());
    }
    
    if (devolucion.getVenta() != null && devolucion.getVenta().getIdVenta() != null) {
        devolucion.setVenta(new Venta(devolucion.getVenta().getIdVenta()));
    } else if (devolucion.getIdVenta() != null) {
        // ✅ Si el frontend envió idVenta directamente
        devolucion.setVenta(new Venta(devolucion.getIdVenta()));
        System.out.println("✅ Venta seteada desde idVenta: " + devolucion.getIdVenta());
    }
    
    System.out.println("🔍 Devolución después de procesar: " + devolucion);
    System.out.println("🔍 Usuario final: " + devolucion.getUsuario());
    
    return ResponseEntity.status(HttpStatus.CREATED)
            .body(devolucionService.crear(devolucion));
}
}
