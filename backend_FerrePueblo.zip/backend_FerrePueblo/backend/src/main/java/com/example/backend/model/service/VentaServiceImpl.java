package com.example.backend.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.model.entity.DetalleVenta;
import com.example.backend.model.entity.Venta;
import com.example.backend.model.repository.VentaRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class VentaServiceImpl implements VentaService{
    private final VentaRepository ventaRepository;

    @Override
    public List<Venta> listarVentas() {
        return ventaRepository.findAll();
    }

    @Override
    public Venta buscarPorId(Integer id) {
        return ventaRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Venta no encontrada con ID: "+id));
    }

    @Override
    @Transactional
    public Venta crear(Venta venta) {
        // Asociar cada detalle con la venta
        if (venta.getDetalleVenta() != null) {
            for (DetalleVenta detalle : venta.getDetalleVenta()) {
                detalle.setVenta(venta);
            }
        }
        return ventaRepository.save(venta);
    }

    @Override
    @Transactional
    public void eliminar(Integer id) {
        Venta venta = buscarPorId(id);
        ventaRepository.delete(venta);
    }  
}
