package com.example.backend.model.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.backend.model.entity.DetalleGuiaEntrada;
import com.example.backend.model.entity.GuiaEntrada;
import com.example.backend.model.repository.GuiaEntradaRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class GuiaEntradaServiceImpl implements GuiaEntradaService {
    
    private final GuiaEntradaRepository guiaEntradaRepository;

    @Override
    @Transactional
    public GuiaEntrada crear(GuiaEntrada guiaEntrada) {
        System.out.println("🔍 ===== GUARDANDO ENTREGA =====");
        
        if (guiaEntrada.getDetalleGuia() != null) {
            for (DetalleGuiaEntrada detalle : guiaEntrada.getDetalleGuia()) {
                detalle.setGuiaEntrada(guiaEntrada);
                System.out.println("🔍 Asociando detalle: Producto=" + detalle.getProducto().getIdProducto() + 
                                  ", Cantidad=" + detalle.getCantidad());
            }
        }
        
        GuiaEntrada saved = guiaEntradaRepository.save(guiaEntrada);
        System.out.println("✅ Entrega guardada con ID: " + saved.getIdGuiaEntrada());
        return saved;
    }
}