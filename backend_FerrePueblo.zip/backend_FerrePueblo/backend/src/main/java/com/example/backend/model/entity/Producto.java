package com.example.backend.model.entity;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "producto")
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "idProducto")
    private Integer idProducto;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(min=2,max=45,message = "Debe tener entre 2 y 45 letras")
    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private Integer stock;
    
    @Column(nullable = false)
    private Double precioVenta;

    @Column(nullable = false)
    private Double precioCompra;

    @Column(nullable = false)
    private String descripcion;

    @Column(nullable = false)
    private String estado;

    @ManyToOne
    @JoinColumn(name = "idProveedor")
    @JsonIgnoreProperties({"productos", "solicitudes"})
    private Proveedor proveedor;

    /*@JsonIgnore
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleVenta> detallesVenta;*/

    /*@JsonIgnore
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DetalleSolicitudCompra> detallesSolicitud;*/
}
