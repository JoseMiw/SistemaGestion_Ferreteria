package com.example.backend.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.model.entity.DetalleSolicitudCompra;
import com.example.backend.model.entity.SolicitudCompra;
import com.example.backend.model.repository.SolicitudCompraRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SolicitudCompraServiceImpl implements SolicitudCompraService{
    private final SolicitudCompraRepository solicitudCompraRepository;

    @Override
    public List<SolicitudCompra> listar() {
        return solicitudCompraRepository.findAll();
    }

    @Override
    public SolicitudCompra buscarPorId(Integer id) {
        return solicitudCompraRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Solicitud no encontrada con ID: " + id));
    }

    @Override
    @Transactional
    public SolicitudCompra crear(SolicitudCompra solicitud) {
        solicitud.setEstado("PENDIENTE");
    
    // ✅ Asegurar que proveedor y usuario estén setteados
    if (solicitud.getProveedor() == null || solicitud.getProveedor().getIdProveedor() == null) {
        throw new RuntimeException("El proveedor es obligatorio");
    }
    
    if (solicitud.getUsuario() == null || solicitud.getUsuario().getIdUsuario() == null) {
        throw new RuntimeException("El usuario es obligatorio");
    }
    
    if (solicitud.getDetalleSolicitud() != null) {
        for (DetalleSolicitudCompra detalle : solicitud.getDetalleSolicitud()) {
            detalle.setSolicitudCompra(solicitud);
        }
    }
    
    return solicitudCompraRepository.save(solicitud);
    }

    @Override
    public SolicitudCompra cambiarEstado(Integer id, String estado) {
        SolicitudCompra solicitud = buscarPorId(id);
        solicitud.setEstado(estado);
        return solicitudCompraRepository.save(solicitud);
    }

    @Override
    @Transactional
    public void eliminar(Integer id) {
        SolicitudCompra solicitud = buscarPorId(id);
        solicitudCompraRepository.delete(solicitud);
    }

}
