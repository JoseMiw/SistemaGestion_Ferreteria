package com.example.backend.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.model.entity.GuiaEntrada;
import com.example.backend.model.service.GuiaEntradaService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/entregas")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class GuiaEntradaController {
    private final GuiaEntradaService guiaEntradaService;

    @PostMapping
    public ResponseEntity<GuiaEntrada> crear(@RequestBody GuiaEntrada guiaEntrada) {

    System.out.println("🔍 ===== ENTREGA RECIBIDA =====");
        System.out.println("🔍 Cantidad: " + guiaEntrada.getCantidad());
        System.out.println("🔍 CostoUnitario: " + guiaEntrada.getCostoUnitario());
        System.out.println("🔍 Subtotal: " + guiaEntrada.getSubtotal());
        System.out.println("🔍 Proveedor ID: " + (guiaEntrada.getProveedor() != null ? guiaEntrada.getProveedor().getIdProveedor() : "null"));
        System.out.println("🔍 Usuario ID: " + (guiaEntrada.getUsuario() != null ? guiaEntrada.getUsuario().getIdUsuario() : "null"));
        System.out.println("🔍 Detalles: " + (guiaEntrada.getDetalleGuia() != null ? guiaEntrada.getDetalleGuia().size() : 0) + " items");
        
        if (guiaEntrada.getDetalleGuia() != null) {
            for (int i = 0; i < guiaEntrada.getDetalleGuia().size(); i++) {
                var detalle = guiaEntrada.getDetalleGuia().get(i);
                System.out.println("🔍 Detalle " + i + ": Producto ID=" + detalle.getProducto().getIdProducto() + 
                                  ", Cantidad=" + detalle.getCantidad() + 
                                  ", Costo=" + detalle.getCostoUnitario() + 
                                  ", Subtotal=" + detalle.getSubtotal());
            }
        }

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(guiaEntradaService.crear(guiaEntrada));
    }

    
}
