package com.example.backend.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente,Integer>{

}
