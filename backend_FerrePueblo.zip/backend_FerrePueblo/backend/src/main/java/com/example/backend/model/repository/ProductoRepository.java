package com.example.backend.model.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.Producto;

public interface ProductoRepository extends JpaRepository<Producto,Integer>{
    List<Producto> findByNombreContainingIgnoreCase(String nombre);
}
