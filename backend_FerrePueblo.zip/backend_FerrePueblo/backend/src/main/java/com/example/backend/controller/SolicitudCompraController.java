package com.example.backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.backend.model.entity.Proveedor;
import com.example.backend.model.entity.SolicitudCompra;
import com.example.backend.model.entity.Usuario;
import com.example.backend.model.service.SolicitudCompraService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/solicitudes")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class SolicitudCompraController {
    private final SolicitudCompraService solicitudCompraService;

    @GetMapping
    public ResponseEntity<List<SolicitudCompra>> listar() {
        return ResponseEntity.ok(solicitudCompraService.listar());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SolicitudCompra> buscarPorId(@PathVariable Integer id) {
    SolicitudCompra solicitud = solicitudCompraService.buscarPorId(id);
    System.out.println("🔍 Solicitud encontrada: " + solicitud);
    System.out.println("🔍 Detalles: " + solicitud.getDetalleSolicitud());
    return ResponseEntity.ok(solicitud);
}

    @PostMapping
    public ResponseEntity<SolicitudCompra> crear(@RequestBody SolicitudCompra solicitud) {
        // ✅ Construir objetos con solo el ID
    if (solicitud.getProveedor() != null && solicitud.getProveedor().getIdProveedor() != null) {
        solicitud.setProveedor(new Proveedor(solicitud.getProveedor().getIdProveedor()));
    }
    
    if (solicitud.getUsuario() != null && solicitud.getUsuario().getIdUsuario() != null) {
        solicitud.setUsuario(new Usuario(solicitud.getUsuario().getIdUsuario()));
    }
    
    return ResponseEntity.status(HttpStatus.CREATED)
            .body(solicitudCompraService.crear(solicitud));
    }

    @PutMapping("/{id}/estado")
    public ResponseEntity<SolicitudCompra> cambiarEstado(
        @PathVariable Integer id, 
        @RequestParam String estado) {
    return ResponseEntity.ok(solicitudCompraService.cambiarEstado(id, estado));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        solicitudCompraService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
