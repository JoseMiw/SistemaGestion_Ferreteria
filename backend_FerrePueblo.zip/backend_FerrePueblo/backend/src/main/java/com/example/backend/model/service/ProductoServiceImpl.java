package com.example.backend.model.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.model.entity.Producto;
import com.example.backend.model.repository.ProductoRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductoServiceImpl implements ProductoService{
    private final ProductoRepository productoRepository;

    @Override
    public List<Producto> cargarProductos() {
        return productoRepository.findAll();
    }

    @Override
    public Producto crear(Producto producto){
        return productoRepository.save(producto);
    }

    @Override
    public Producto buscarPorId(Integer id) {
        return productoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
    }

    @Override
    public Producto actualizar(Integer id, Producto producto) {
        Producto productoexistente=buscarPorId(id);

        productoexistente.setNombre(producto.getNombre());
        productoexistente.setStock(producto.getStock());
        productoexistente.setPrecioVenta(producto.getPrecioVenta());
        productoexistente.setPrecioCompra(producto.getPrecioCompra());
        productoexistente.setDescripcion(producto.getDescripcion());
        productoexistente.setEstado(producto.getEstado());

        return productoRepository.save(productoexistente);
    }

    @Override
    @Transactional
    public void eliminar(Integer id) {
        Producto producto=buscarPorId(id);

        /*if (producto.getDetallesVenta() != null) {
            producto.getDetallesVenta().clear();
        }*/
        /*if (producto.getDetallesSolicitud() != null) {
            producto.getDetallesSolicitud().clear();
        }*/

        productoRepository.delete(producto);
    }

    @Override
    public List<Producto> buscarPorNombre(String nombre) {
        return productoRepository.findByNombreContainingIgnoreCase(nombre);
    }

    @Override
    @Transactional
    public Producto actualizarStock(Integer id, Integer cantidad) {
        Producto producto = buscarPorId(id);
        
        //Verifica si hay suficiente stock
        if (producto.getStock() < cantidad) {
            throw new RuntimeException("Stock insuficiente. Stock actual: " + producto.getStock());
        }
        
        //Resta la cantidad del stock
        producto.setStock(producto.getStock() - cantidad);
        return productoRepository.save(producto);
    }

    @Override
    @Transactional
    public Producto aumentarStock(Integer id, Integer cantidad) {
    Producto producto = buscarPorId(id);
    producto.setStock(producto.getStock() + cantidad);
    return productoRepository.save(producto);
    }
}
