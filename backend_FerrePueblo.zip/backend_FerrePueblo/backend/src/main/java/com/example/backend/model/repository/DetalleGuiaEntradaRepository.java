package com.example.backend.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.DetalleGuiaEntrada;

public interface DetalleGuiaEntradaRepository extends JpaRepository<DetalleGuiaEntrada,Integer>{

}
