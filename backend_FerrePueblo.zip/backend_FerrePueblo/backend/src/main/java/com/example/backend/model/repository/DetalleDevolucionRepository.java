package com.example.backend.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.DetalleDevolucion;

public interface DetalleDevolucionRepository extends JpaRepository<DetalleDevolucion, Integer>{

}
