package com.example.backend.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.backend.model.entity.DetalleVenta;

public interface DetalleVentaRepository extends JpaRepository<DetalleVenta,Integer>{

}
